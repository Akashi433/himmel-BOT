/*
SCRIPT BY © Yousoo 
•• thanks to own web widipie sebagai penyedia api
Foll saluran aku dungs: https://whatsapp.com/channel/0029VakAg04545umLWxbWa0i
*/

const yts = require('yt-search')
const fs = require('fs')
const { pipeline } = require('stream')
const { promisify } = require('util')
const os = require('os')
const axios = require('axios')

const streamPipeline = promisify(pipeline);

var handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) throw `Gunakan contoh ${usedPrefix}${command} naruto blue bird`;

  await conn.reply(m.chat, "_「P R O C E S S 」_\n Sedang mencari dan mengunduh audio...", m);

  let search = await yts(text);
  let vid = search.videos[0];
  if (!search) throw 'Video tidak ditemukan, coba judul lain';
  let { title, thumbnail, timestamp, views, ago, url } = vid;
  let wm = 'Bochi By Ranz';
  let wm2 = 'Play 🎵';

  let captvid = `╭──── 〔 Y O U T U B E 〕 ─⬣
  ⬡ Title: ${title}
  ⬡ Duration: ${timestamp}
  ⬡ Views: ${views}
  ⬡ Uploaded: ${ago}
  ⬡ Link: ${url}
╰────────⬣`;

  const response = await axios.get(`https://widipe.com/download/ytdl?url=${encodeURIComponent(url)}`);
  const mp3Url = response.data.result.mp3;

  const audioResponse = await axios.get(mp3Url, { responseType: 'stream' });

  const tmpDir = os.tmpdir();
  const audioFilePath = `${tmpDir}/${title}.mp3`;
  const writableStream = fs.createWriteStream(audioFilePath);

  await streamPipeline(audioResponse.data, writableStream);

  let audioMessage = {
    audio: {
      url: audioFilePath
    },
    mimetype: 'audio/mp4',
    fileName: `${title}`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 2,
        mediaUrl: url,
        title: title,
        body: wm2,
        sourceUrl: url,
        thumbnailUrl: thumbnail
      }
    }
  };

  await conn.sendMessage(m.chat, audioMessage, { quoted: m });

  fs.unlink(audioFilePath, (err) => {
    if (err) {
      console.error(`Gagal menghapus file audio: ${err}`);
    } else {
      console.log(`File audio dihapus: ${audioFilePath}`);
    }
  });
};

handler.help = ['play'].map((v) => v + ' <query>');
handler.tags = ['downloader'];
handler.command = /^(play)$/i;

module.exports =handler;